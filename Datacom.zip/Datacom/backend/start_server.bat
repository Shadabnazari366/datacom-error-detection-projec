@echo off
echo Starting FastAPI Server...
python main.py


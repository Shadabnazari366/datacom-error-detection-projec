"""
Error Detection Methods Implementation
"""
import binascii


def calculate_parity(data: str, parity_type: str = "even") -> str:
    """
    Calculate parity bit for the data.
    parity_type: "even" or "odd"
    Returns: "0" or "1"
    """
    binary_data = ''.join(format(ord(c), '08b') for c in data)
    count_ones = binary_data.count('1')
    
    if parity_type == "even":
        return "0" if count_ones % 2 == 0 else "1"
    else:  # odd
        return "1" if count_ones % 2 == 0 else "0"


def calculate_2d_parity(data: str, rows: int = 8, cols: int = 8) -> str:
    """
    Calculate 2D Parity (Matrix Parity).
    Returns: row_parities|col_parities (hex encoded)
    """
    # Pad data to fit matrix
    total_chars = rows * cols
    padded_data = data.ljust(total_chars, '\0')
    
    # Create matrix
    matrix = []
    for i in range(rows):
        row = padded_data[i*cols:(i+1)*cols]
        matrix.append([ord(c) for c in row])
    
    # Calculate row parities
    row_parities = []
    for row in matrix:
        binary_row = ''.join(format(c, '08b') for c in row)
        count_ones = binary_row.count('1')
        row_parities.append('1' if count_ones % 2 == 1 else '0')
    
    # Calculate column parities
    col_parities = []
    for col_idx in range(cols):
        binary_col = ''.join(format(matrix[row_idx][col_idx], '08b') for row_idx in range(rows))
        count_ones = binary_col.count('1')
        col_parities.append('1' if count_ones % 2 == 1 else '0')
    
    # Combine and convert to hex
    combined = ''.join(row_parities) + ''.join(col_parities)
    # Convert binary string to hex
    hex_value = hex(int(combined, 2))[2:].upper()
    return hex_value


def calculate_crc(data: str, crc_type: str = "CRC16") -> str:
    """
    Calculate CRC checksum.
    crc_type: "CRC8", "CRC16", or "CRC32"
    Returns: hex string
    """
    data_bytes = data.encode('utf-8')
    
    if crc_type == "CRC8":
        # CRC-8 polynomial: x^8 + x^2 + x + 1 (0x07)
        polynomial = 0x07
        crc = 0
        for byte in data_bytes:
            crc ^= byte
            for _ in range(8):
                if crc & 0x80:
                    crc = (crc << 1) ^ polynomial
                else:
                    crc <<= 1
                crc &= 0xFF
        return format(crc, '02X')
    
    elif crc_type == "CRC16":
        # CRC-16-CCITT polynomial: x^16 + x^12 + x^5 + 1 (0x1021)
        return format(binascii.crc_hqx(data_bytes, 0), '04X')
    
    elif crc_type == "CRC32":
        # CRC-32 polynomial
        return format(binascii.crc32(data_bytes) & 0xFFFFFFFF, '08X')
    
    return "0000"


def calculate_hamming_code(data: str) -> str:
    """
    Calculate Hamming Code for error detection/correction.
    Uses Hamming(7,4) encoding: 4 data bits + 3 parity bits.
    Returns: hex string of encoded data
    """
    def hamming_encode_4bits(bits: str) -> str:
        """Encode 4 bits using Hamming(7,4)"""
        if len(bits) < 4:
            bits = bits.ljust(4, '0')
        
        d1, d2, d3, d4 = map(int, bits[:4])
        
        # Calculate parity bits
        p1 = (d1 + d2 + d4) % 2
        p2 = (d1 + d3 + d4) % 2
        p3 = (d2 + d3 + d4) % 2
        
        # Hamming code: p1 p2 d1 p3 d2 d3 d4
        encoded = f"{p1}{p2}{d1}{p3}{d2}{d3}{d4}"
        return encoded
    
    # Convert data to binary
    binary_data = ''.join(format(ord(c), '08b') for c in data)
    
    # Encode in 4-bit blocks
    encoded_bits = []
    for i in range(0, len(binary_data), 4):
        block = binary_data[i:i+4]
        encoded_bits.append(hamming_encode_4bits(block))
    
    # Convert to hex
    encoded_str = ''.join(encoded_bits)
    # Pad to multiple of 8 bits for hex conversion
    while len(encoded_str) % 8 != 0:
        encoded_str += '0'
    
    hex_value = ''
    for i in range(0, len(encoded_str), 8):
        byte = encoded_str[i:i+8]
        hex_value += format(int(byte, 2), '02X')
    
    return hex_value


def verify_parity(data: str, control_info: str, parity_type: str = "even") -> bool:
    """Verify parity"""
    calculated = calculate_parity(data, parity_type)
    return calculated == control_info


def verify_2d_parity(data: str, control_info: str) -> bool:
    """Verify 2D Parity"""
    calculated = calculate_2d_parity(data)
    return calculated.upper() == control_info.upper()


def verify_crc(data: str, control_info: str, crc_type: str) -> bool:
    """Verify CRC"""
    calculated = calculate_crc(data, crc_type)
    return calculated.upper() == control_info.upper()


def verify_hamming_code(data: str, control_info: str) -> bool:
    """Verify Hamming Code"""
    calculated = calculate_hamming_code(data)
    return calculated.upper() == control_info.upper()


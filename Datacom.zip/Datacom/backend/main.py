"""
FastAPI Server for Data Communication Error Detection System
"""
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import json
import os
import asyncio
from typing import Set
from error_detection import (
    calculate_parity, calculate_2d_parity, calculate_crc, calculate_hamming_code,
    verify_parity, verify_2d_parity, verify_crc, verify_hamming_code
)
from data_corruption import CORRUPTION_METHODS

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SETTINGS_FILE = "settings.json"

# WebSocket connection manager for Client 2 (receiver)
class ConnectionManager:
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)
    
    async def send_packet(self, packet: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(packet)
            except:
                pass

manager = ConnectionManager()


class Packet(BaseModel):
    data: str
    method: str
    control_information: str


class CalculateRequest(BaseModel):
    data: str
    method: str


class Settings(BaseModel):
    corrupt_data: bool
    corruption_method: str


def load_settings():
    """Load settings from JSON file"""
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r') as f:
            return json.load(f)
    return {"corrupt_data": False, "corruption_method": "bit_flip"}


def save_settings(settings: dict):
    """Save settings to JSON file"""
    with open(SETTINGS_FILE, 'w') as f:
        json.dump(settings, f, indent=2)


@app.get("/")
def root():
    return {"message": "Data Communication Error Detection Server"}


@app.get("/api/settings")
def get_settings():
    """Get current server settings"""
    return load_settings()


@app.post("/api/settings")
def update_settings(settings: Settings):
    """Update server settings"""
    settings_dict = {
        "corrupt_data": settings.corrupt_data,
        "corruption_method": settings.corruption_method
    }
    save_settings(settings_dict)
    return {"message": "Settings updated", "settings": settings_dict}


@app.post("/api/calculate")
def calculate_control_info(request: CalculateRequest):
    """
    Calculate control information for given data and method
    """
    data = request.data
    method = request.method
    
    try:
        if method == "Parity":
            control_info = calculate_parity(data, "even")
        elif method == "2D Parity":
            control_info = calculate_2d_parity(data)
        elif method.startswith("CRC"):
            control_info = calculate_crc(data, method)
        elif method == "Hamming Code":
            control_info = calculate_hamming_code(data)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown method: {method}")
        
        return {
            "control_information": control_info,
            "data": data,
            "method": method
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Calculation error: {str(e)}")


@app.websocket("/ws/sender")
async def websocket_sender(websocket: WebSocket):
    """
    WebSocket endpoint for Client 1 (Data Sender)
    Receives packets and forwards to Client 2 via WebSocket
    """
    await websocket.accept()
    try:
        while True:
            # Receive packet from Client 1
            data = await websocket.receive_json()
            
            settings = load_settings()
            
            packet_data = data.get("data", "")
            method = data.get("method", "")
            control_info = data.get("control_information", "")
            
            # Corrupt data if enabled
            if settings.get("corrupt_data", False):
                corruption_method_name = settings.get("corruption_method", "bit_flip")
                if corruption_method_name in CORRUPTION_METHODS:
                    packet_data = CORRUPTION_METHODS[corruption_method_name](packet_data)
            
            # Create corrupted packet
            corrupted_packet = {
                "data": packet_data,
                "method": method,
                "control_information": control_info
            }
            
            # Send confirmation to Client 1
            await websocket.send_json({
                "status": "success",
                "message": "Packet received and processed",
                "corrupted_data": packet_data
            })
            
            # Forward to all connected Client 2 receivers
            await manager.send_packet(corrupted_packet)
            
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.send_json({"status": "error", "message": str(e)})
        except:
            pass


@app.websocket("/ws/receiver")
async def websocket_receiver(websocket: WebSocket):
    """
    WebSocket endpoint for Client 2 (Receiver)
    Automatically receives packets and sends verification results
    """
    await manager.connect(websocket)
    try:
        await websocket.send_json({
            "status": "connected",
            "message": "Connected to server. Waiting for packets..."
        })
        
        while True:
            # Keep connection alive - packets are pushed via manager.send_packet()
            # Wait for any message (ping or other) to keep connection active
            try:
                message = await websocket.receive()
                # Handle text messages (ping)
                if "text" in message:
                    if message["text"] == "ping":
                        await websocket.send_json({"status": "alive"})
                # Handle JSON messages
                elif "json" in message:
                    await websocket.send_json({"status": "alive"})
            except Exception:
                # If receive fails, connection might be closed
                break
            
    except WebSocketDisconnect:
        pass
    except Exception as e:
        pass
    finally:
        manager.disconnect(websocket)


def verify_packet_data(data: str, method: str, control_info: str):
    """
    Verify if the received data matches the control information
    Returns tuple: (is_correct, calculated_control)
    """
    is_correct = False
    calculated = control_info  # Default to received control info
    
    try:
        if method == "Parity" or method.startswith("Parity"):
            parity_type = "even"  # Default, could be extracted from method
            calculated = calculate_parity(data, parity_type)
            is_correct = calculated == control_info
        
        elif method == "2D Parity":
            calculated = calculate_2d_parity(data)
            is_correct = calculated.upper() == control_info.upper()
        
        elif method.startswith("CRC"):
            calculated = calculate_crc(data, method)
            is_correct = calculated.upper() == control_info.upper()
        
        elif method == "Hamming Code":
            calculated = calculate_hamming_code(data)
            is_correct = calculated.upper() == control_info.upper()
        else:
            raise ValueError(f"Unknown verification method: {method}")
        
        return is_correct, calculated
    
    except Exception as e:
        raise ValueError(f"Verification error: {str(e)}")


@app.post("/api/verify")
def verify_packet(packet: Packet):
    """
    HTTP endpoint for verification (kept for compatibility)
    """
    try:
        is_correct, calculated = verify_packet_data(
            packet.data, 
            packet.method, 
            packet.control_information
        )
        return {
            "is_correct": is_correct,
            "calculated_control": calculated
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification error: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


"""
Data Corruption Methods Implementation
"""
import random


def bit_flip(data: str) -> str:
    """Flip a random bit in the binary representation"""
    if not data:
        return data
    
    # Convert to binary
    char_list = list(data)
    char_idx = random.randint(0, len(char_list) - 1)
    char = char_list[char_idx]
    
    # Flip a random bit
    binary = format(ord(char), '08b')
    bit_idx = random.randint(0, 7)
    flipped_bit = '1' if binary[bit_idx] == '0' else '0'
    new_binary = binary[:bit_idx] + flipped_bit + binary[bit_idx+1:]
    
    char_list[char_idx] = chr(int(new_binary, 2))
    return ''.join(char_list)


def character_substitution(data: str) -> str:
    """Replace a random character with another character"""
    if not data:
        return data
    
    char_list = list(data)
    idx = random.randint(0, len(char_list) - 1)
    # Replace with a random printable ASCII character
    char_list[idx] = chr(random.randint(32, 126))
    return ''.join(char_list)


def character_deletion(data: str) -> str:
    """Remove a random character"""
    if not data:
        return data
    
    char_list = list(data)
    idx = random.randint(0, len(char_list) - 1)
    char_list.pop(idx)
    return ''.join(char_list)


def character_insertion(data: str) -> str:
    """Insert a random character at a random position"""
    if not data:
        return chr(random.randint(32, 126))
    
    char_list = list(data)
    idx = random.randint(0, len(char_list))
    char_list.insert(idx, chr(random.randint(32, 126)))
    return ''.join(char_list)


def character_swapping(data: str) -> str:
    """Swap two adjacent characters"""
    if len(data) < 2:
        return data
    
    char_list = list(data)
    idx = random.randint(0, len(char_list) - 2)
    char_list[idx], char_list[idx + 1] = char_list[idx + 1], char_list[idx]
    return ''.join(char_list)


def multiple_bit_flips(data: str) -> str:
    """Flip multiple random bits"""
    if not data:
        return data
    
    result = data
    num_flips = random.randint(2, min(5, len(data)))
    for _ in range(num_flips):
        result = bit_flip(result)
    return result


def burst_error(data: str) -> str:
    """Corrupt a sequence of 3-8 consecutive characters"""
    if len(data) < 3:
        return character_substitution(data)
    
    char_list = list(data)
    burst_length = random.randint(3, min(8, len(data)))
    start_idx = random.randint(0, len(data) - burst_length)
    
    # Corrupt the burst by replacing with random characters
    for i in range(start_idx, start_idx + burst_length):
        char_list[i] = chr(random.randint(32, 126))
    
    return ''.join(char_list)


CORRUPTION_METHODS = {
    "bit_flip": bit_flip,
    "character_substitution": character_substitution,
    "character_deletion": character_deletion,
    "character_insertion": character_insertion,
    "character_swapping": character_swapping,
    "multiple_bit_flips": multiple_bit_flips,
    "burst_error": burst_error
}


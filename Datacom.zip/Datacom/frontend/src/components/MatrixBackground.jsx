import React, { useEffect, useRef } from 'react'

function MatrixBackground() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const context = canvas.getContext('2d')

    // Set canvas to full viewport
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Create alphabet
    const katakana = 'アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン'
    const latin = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    const nums = '0123456789'
    const alphabet = katakana + latin + nums

    // Calculate columns
    const fontSize = 16
    const columns = canvas.width / fontSize

    // Initialize raindrops array
    const rainDrops = []
    for (let x = 0; x < columns; x++) {
      rainDrops[x] = 1
    }

    // Draw function
    const draw = () => {
      // Paint transparent black to create trail effect
      context.fillStyle = 'rgba(0, 0, 0, 0.05)'
      context.fillRect(0, 0, canvas.width, canvas.height)

      // Set font and color
      context.fillStyle = '#0F0' // Matrix green
      context.font = fontSize + 'px monospace'

      // Draw characters
      for (let i = 0; i < rainDrops.length; i++) {
        // Pick random character
        const text = alphabet.charAt(Math.floor(Math.random() * alphabet.length))
        
        // Draw character
        context.fillText(text, i * fontSize, rainDrops[i] * fontSize)

        // Move raindrop down, reset to top with some randomness
        if (rainDrops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          rainDrops[i] = 0
        }
        rainDrops[i]++
      }
    }

    // Handle window resize
    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      
      // Recalculate columns
      const newColumns = canvas.width / fontSize
      while (rainDrops.length < newColumns) {
        rainDrops.push(1)
      }
      rainDrops.splice(newColumns)
    }

    window.addEventListener('resize', handleResize)

    // Start animation
    const interval = setInterval(draw, 30)

    // Cleanup
    return () => {
      clearInterval(interval)
      window.removeEventListener('resize', handleResize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: -1,
        background: '#000'
      }}
    />
  )
}

export default MatrixBackground


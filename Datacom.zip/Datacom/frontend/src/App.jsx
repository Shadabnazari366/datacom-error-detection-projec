import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import Client1 from './pages/Client1'
import Server from './pages/Server'
import Client2 from './pages/Client2'
import MatrixBackground from './components/MatrixBackground'

function Navigation() {
  const location = useLocation()
  
  return (
    <nav className="nav">
      <Link to="/client1">
        <button className={location.pathname === '/client1' ? 'active' : ''}>
          Client 1 - Data Sender
        </button>
      </Link>
      <Link to="/server">
        <button className={location.pathname === '/server' ? 'active' : ''}>
          Server - Settings
        </button>
      </Link>
      <Link to="/client2">
        <button className={location.pathname === '/client2' ? 'active' : ''}>
          Client 2 - Receiver
        </button>
      </Link>
    </nav>
  )
}

function App() {
  return (
    <Router>
      <MatrixBackground />
      <div className="container">
        <h1>Data Communication Error Detection System</h1>
        <Navigation />
        <Routes>
          <Route path="/" element={<Client1 />} />
          <Route path="/client1" element={<Client1 />} />
          <Route path="/server" element={<Server />} />
          <Route path="/client2" element={<Client2 />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App


import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'

//const API_URL = 'http://localhost:8000'
//const WS_URL = 'ws://localhost:8000'

const API_URL = `http://${window.location.hostname}:8000`;
const WS_URL = `ws://${window.location.hostname}:8000`;

function Client2() {
  const [history, setHistory] = useState([])
  const [currentPacket, setCurrentPacket] = useState(null)
  const [error, setError] = useState('')
  const [connected, setConnected] = useState(false)
  const wsRef = useRef(null)

  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('client2_history')
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory))
    }
  }, [])

  // Save history to localStorage
  const saveHistory = (newHistory) => {
    setHistory(newHistory)
    localStorage.setItem('client2_history', JSON.stringify(newHistory))
  }

  const verifyPacket = async (packet) => {
    try {
      const response = await axios.post(`${API_URL}/api/verify`, packet)
      return response.data
    } catch (err) {
      throw new Error(err.response?.data?.detail || err.message || 'Verification failed')
    }
  }

  // WebSocket connection and automatic packet reception
  useEffect(() => {
    const ws = new WebSocket(`${WS_URL}/ws/receiver`)
    wsRef.current = ws

    ws.onopen = () => {
      setConnected(true)
      setError('')
    }

    ws.onmessage = async (event) => {
      try {
        const data = JSON.parse(event.data)
        
        // Handle connection confirmation
        if (data.status === 'connected' || data.status === 'alive') {
          return
        }

        // Handle incoming packet
        if (data.data && data.method && data.control_information) {
          const packet = {
            data: data.data,
            method: data.method,
            control_information: data.control_information
          }

          // Verify the packet
          try {
            const verification = await verifyPacket(packet)
            
            const result = {
              received_data: packet.data,
              method: packet.method,
              sent_control: packet.control_information,
              computed_control: verification.calculated_control,
              is_correct: verification.is_correct,
              timestamp: new Date().toISOString()
            }

            setCurrentPacket(result)
            setHistory(prev => {
              const newHistory = [result, ...prev]
              saveHistory(newHistory)
              return newHistory
            })
          } catch (verifyErr) {
            setError(`Verification error: ${verifyErr.message}`)
          }
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err)
      }
    }

    ws.onerror = (error) => {
      setError('WebSocket connection error')
      setConnected(false)
    }

    ws.onclose = () => {
      setConnected(false)
      // Attempt to reconnect after 3 seconds
      setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.CLOSED) {
          // Reconnection will be handled by useEffect
        }
      }, 3000)
    }

    // Send keepalive message periodically
    const keepAliveInterval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send('ping')
      }
    }, 30000)

    return () => {
      clearInterval(keepAliveInterval)
      if (ws.readyState === WebSocket.OPEN) {
        ws.close()
      }
    }
  }, [])

  return (
    <div className="page-container">
      <h2>Client 2 - Receiver & Error Checker</h2>
      
      <div style={{ 
        marginBottom: '15px', 
        padding: '10px', 
        borderRadius: '6px',
        background: connected ? 'rgba(0, 255, 0, 0.2)' : 'rgba(255, 0, 0, 0.2)',
        border: `2px solid ${connected ? '#0F0' : '#ff0000'}`,
        color: connected ? '#0F0' : '#ff0000',
        textAlign: 'center',
        fontWeight: '500',
        textShadow: connected ? '0 0 10px #0F0' : '0 0 10px #ff0000'
      }}>
        {connected ? '✓ WebSocket Connected - Waiting for packets...' : '✗ WebSocket Disconnected - Reconnecting...'}
      </div>

      {error && <div className="error">{error}</div>}

      {currentPacket && (
        <div className="result-box" style={{ marginTop: '20px' }}>
          <h3>Verification Result:</h3>
          <div className="result-item">
            <span className="result-label">Received Data:</span>
            <span className="result-value">{currentPacket.received_data}</span>
          </div>
          <div className="result-item">
            <span className="result-label">Method:</span>
            <span className="result-value">{currentPacket.method}</span>
          </div>
          <div className="result-item">
            <span className="result-label">Sent Check Bits:</span>
            <span className="result-value">{currentPacket.sent_control}</span>
          </div>
          <div className="result-item">
            <span className="result-label">Computed Check Bits:</span>
            <span className="result-value">{currentPacket.computed_control}</span>
          </div>
          <div className={`status ${currentPacket.is_correct ? 'correct' : 'corrupted'}`}>
            Status: {currentPacket.is_correct ? 'DATA CORRECT' : 'DATA CORRUPTED'}
          </div>
        </div>
      )}

      {history.length > 0 && (
        <div style={{ marginTop: '30px' }}>
          <h3 style={{ marginBottom: '20px', color: '#555' }}>History:</h3>
          {history.map((item, index) => (
            <div key={index} className={`history-item ${item.is_correct ? 'correct' : 'corrupted'}`}>
              <div className="result-item">
                <span className="result-label">Data:</span>
                <span className="result-value">{item.received_data}</span>
              </div>
              <div className="result-item">
                <span className="result-label">Method:</span>
                <span className="result-value">{item.method}</span>
              </div>
              <div className="result-item">
                <span className="result-label">Sent:</span>
                <span className="result-value">{item.sent_control}</span>
              </div>
              <div className="result-item">
                <span className="result-label">Computed:</span>
                <span className="result-value">{item.computed_control}</span>
              </div>
              <div style={{ marginTop: '10px' }}>
                <strong style={{ color: item.is_correct ? '#0F0' : '#ff0000', textShadow: item.is_correct ? '0 0 10px #0F0' : '0 0 10px #ff0000' }}>
                  {item.is_correct ? '✓ DATA CORRECT' : '✗ DATA CORRUPTED'}
                </strong>
                <span style={{ marginLeft: '15px', color: '#0F0', fontSize: '14px', opacity: 0.7 }}>
                  {new Date(item.timestamp).toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {history.length === 0 && !currentPacket && (
        <div style={{ marginTop: '20px', textAlign: 'center', color: '#0F0', opacity: 0.7 }}>
          No received data yet. Send data from Client 1 first.
        </div>
      )}
    </div>
  )
}

export default Client2


import React, { useState, useEffect } from 'react'
import axios from 'axios'

const API_URL = `http://${window.location.hostname}:8000`;

const CORRUPTION_METHODS = [
  { value: 'bit_flip', label: 'Bit Flip' },
  { value: 'character_substitution', label: 'Character Substitution' },
  { value: 'character_deletion', label: 'Character Deletion' },
  { value: 'character_insertion', label: 'Character Insertion' },
  { value: 'character_swapping', label: 'Character Swapping' },
  { value: 'multiple_bit_flips', label: 'Multiple Bit Flips' },
  { value: 'burst_error', label: 'Burst Error' }
]

function Server() {
  const [corruptData, setCorruptData] = useState(false)
  const [corruptionMethod, setCorruptionMethod] = useState('bit_flip')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/settings`)
      setCorruptData(response.data.corrupt_data)
      setCorruptionMethod(response.data.corruption_method)
    } catch (err) {
      setError('Failed to load settings')
    }
  }

  const handleSave = async () => {
    setLoading(true)
    setError('')
    setMessage('')

    try {
      const response = await axios.post(`${API_URL}/api/settings`, {
        corrupt_data: corruptData,
        corruption_method: corruptionMethod
      })
      setMessage('Settings saved successfully!')
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Failed to save settings')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="page-container">
      <h2>Server - Data Corruption Settings</h2>
      
      <div className="checkbox-group">
        <input
          type="checkbox"
          id="corrupt"
          checked={corruptData}
          onChange={(e) => setCorruptData(e.target.checked)}
        />
        <label htmlFor="corrupt">Enable Data Corruption</label>
      </div>

      <div className="form-group">
        <label htmlFor="corruption-method">Corruption Method:</label>
        <select
          id="corruption-method"
          value={corruptionMethod}
          onChange={(e) => setCorruptionMethod(e.target.value)}
          disabled={!corruptData}
        >
          {CORRUPTION_METHODS.map(method => (
            <option key={method.value} value={method.value}>
              {method.label}
            </option>
          ))}
        </select>
      </div>

      <button onClick={handleSave} disabled={loading}>
        {loading ? 'Saving...' : 'Save Settings'}
      </button>

      {error && <div className="error">{error}</div>}
      {message && <div style={{ marginTop: '15px', color: '#0F0', fontWeight: '500', textShadow: '0 0 5px #0F0' }}>{message}</div>}

      <div style={{ marginTop: '30px', padding: '20px', background: 'rgba(0, 0, 0, 0.7)', border: '2px solid #0F0', borderRadius: '8px' }}>
        <h3 style={{ marginBottom: '15px', color: '#0F0', textShadow: '0 0 5px #0F0' }}>Current Settings:</h3>
        <div className="result-item">
          <span className="result-label">Corrupt Data:</span>
          <span className="result-value">{corruptData ? 'Enabled' : 'Disabled'}</span>
        </div>
        <div className="result-item">
          <span className="result-label">Method:</span>
          <span className="result-value">
            {CORRUPTION_METHODS.find(m => m.value === corruptionMethod)?.label || corruptionMethod}
          </span>
        </div>
      </div>
    </div>
  )
}

export default Server


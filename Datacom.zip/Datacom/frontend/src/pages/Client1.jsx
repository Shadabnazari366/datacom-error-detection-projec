import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'

//const API_URL = 'http://localhost:8000'
//const WS_URL = 'ws://localhost:8000'

const API_URL = `http://${window.location.hostname}:8000`;
const WS_URL = `ws://${window.location.hostname}:8000`;



function Client1() {
  const [data, setData] = useState('')
  const [method, setMethod] = useState('Parity')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [connected, setConnected] = useState(false)
  const wsRef = useRef(null)

  const pendingPacketRef = useRef(null)

  useEffect(() => {
    // Establish WebSocket connection
    const ws = new WebSocket(`${WS_URL}/ws/sender`)
    wsRef.current = ws

    ws.onopen = () => {
      setConnected(true)
      setError('')
    }

    ws.onmessage = (event) => {
      const response = JSON.parse(event.data)
      if (response.status === 'success') {
        const packet = pendingPacketRef.current
        if (packet) {
          setResult({
            sent: {
              data: packet.data,
              method: packet.method,
              control_information: packet.control_information
            },
            message: 'Data sent successfully via WebSocket! Check Client 2 to see the received data.',
            corrupted_data: response.corrupted_data
          })
          pendingPacketRef.current = null
        }
        setLoading(false)
      } else if (response.status === 'error') {
        setError(response.message || 'Failed to send data')
        setLoading(false)
        pendingPacketRef.current = null
      }
    }

    ws.onerror = (error) => {
      setError('WebSocket connection error')
      setConnected(false)
      setLoading(false)
      pendingPacketRef.current = null
    }

    ws.onclose = () => {
      setConnected(false)
    }

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close()
      }
    }
  }, [])

  const handleSend = async () => {
    if (!data.trim()) {
      setError('Please enter some data')
      return
    }

    if (!connected || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      setError('WebSocket not connected. Please wait...')
      return
    }

    setLoading(true)
    setError('')
    setResult(null)

    try {
      // First, calculate control information via HTTP
      const calcResponse = await axios.post(`${API_URL}/api/calculate`, {
        data: data,
        method: method
      })
      
      const controlInfo = calcResponse.data.control_information

      // Format: DATA|METHOD|CONTROL_INFORMATION
      const packet = {
        data: data,
        method: method,
        control_information: controlInfo
      }

      // Store packet for when server confirms
      pendingPacketRef.current = {
        data: data,
        method: method,
        control_information: controlInfo
      }

      // Send via WebSocket
      wsRef.current.send(JSON.stringify(packet))
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Failed to calculate control information')
      setLoading(false)
    }
  }

  return (
    <div className="page-container">
      <h2>Client 1 - Data Sender</h2>
      
      <div style={{ 
        marginBottom: '15px', 
        padding: '10px', 
        borderRadius: '6px',
        background: connected ? 'rgba(0, 255, 0, 0.2)' : 'rgba(255, 0, 0, 0.2)',
        border: `2px solid ${connected ? '#0F0' : '#ff0000'}`,
        color: connected ? '#0F0' : '#ff0000',
        textAlign: 'center',
        fontWeight: '500',
        textShadow: connected ? '0 0 10px #0F0' : '0 0 10px #ff0000'
      }}>
        {connected ? '✓ WebSocket Connected' : '✗ WebSocket Disconnected'}
      </div>
      
      <div className="form-group">
        <label htmlFor="data">Enter Text Data:</label>
        <input
          type="text"
          id="data"
          value={data}
          onChange={(e) => setData(e.target.value)}
          placeholder="Enter text to send (e.g., HELLO)"
        />
      </div>

      <div className="form-group">
        <label htmlFor="method">Select Error Detection Method:</label>
        <select
          id="method"
          value={method}
          onChange={(e) => setMethod(e.target.value)}
        >
          <option value="Parity">Parity</option>
          <option value="2D Parity">2D Parity</option>
          <option value="CRC8">CRC-8</option>
          <option value="CRC16">CRC-16</option>
          <option value="CRC32">CRC-32</option>
          <option value="Hamming Code">Hamming Code</option>
        </select>
      </div>

      <button onClick={handleSend} disabled={loading}>
        {loading ? 'Sending...' : 'Send Data'}
      </button>

      {error && <div className="error">{error}</div>}

      {result && (
        <div className="result-box">
          <h3>Sent Packet:</h3>
          <div className="result-item">
            <span className="result-label">Data:</span>
            <span className="result-value">{result.sent.data}</span>
          </div>
          <div className="result-item">
            <span className="result-label">Method:</span>
            <span className="result-value">{result.sent.method}</span>
          </div>
          <div className="result-item">
            <span className="result-label">Control Info:</span>
            <span className="result-value">{result.sent.control_information}</span>
          </div>
          <p style={{ marginTop: '15px', color: '#0F0', fontWeight: '500', textShadow: '0 0 5px #0F0' }}>
            {result.message}
          </p>
        </div>
      )}
    </div>
  )
}

export default Client1


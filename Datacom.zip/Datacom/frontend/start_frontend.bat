@echo off
echo Starting Frontend Development Server...
npm run dev -- --host

